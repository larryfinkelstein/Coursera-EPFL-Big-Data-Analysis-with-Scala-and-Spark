"# hadoop-common-2.2.0-bin-32bit" 
